ng-closure-runner
=================

Wraps Google Closure Compiler for AngularJS-specific compile passes
